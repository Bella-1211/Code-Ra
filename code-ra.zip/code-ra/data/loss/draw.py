import numpy as np
from matplotlib import pyplot as plt, axes
from scipy.interpolate import make_interp_spline


def draw_loss():
    x=[]
    y=[]
    y2=[]
    y3=[]
    x_new = []
    y_new = []
    y2_new = []
    y3_new = []
    for i in range(1000):
       x.append(i)
    with open('D:/My/研究生学习资料/小论文-2/实验/code-ra(2)/code-ra/data/loss/loss_0.005.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l1 in line.split():
            y.append(float(l1)*(-1.0))
    with open('D:/My/研究生学习资料/小论文-2/实验/code-ra(2)/code-ra/data/loss/loss_0.02.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l2 in line.split():
            y2.append(float(l2)*(-1.0))
    with open('D:/My/研究生学习资料/小论文-2/实验/code-ra(2)/code-ra/data/loss/loss_0.01.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l3 in line.split():
            y3.append(float(l3)*(-1.0))

    plt.figure(figsize=(6, 4))
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.ylim(0, 3000)
    plt.margins(x=0)
    plt.margins(y=0)
    # 调整刻度线方向

    # 间隔取值
    for i in range(0, len(x), 4):
        x_new.append(x[i])
    for i in range(0, len(y), 4):
        y_new.append(y[i])
    for i in range(0, len(y2), 4):
        y2_new.append(y2[i])
    for i in range(0, len(y3), 4):
        y3_new.append(y3[i])

    # 平滑曲线
    # x_smooth = np.linspace(min(x_new), max(x_new), 5000)
    # y1_smooth = make_interp_spline(x_new, y_new)(x_smooth)
    # y2_smooth = make_interp_spline(x_new, y2_new)(x_smooth)
    # y3_smooth = make_interp_spline(x_new, y3_new)(x_smooth)

    #  画图
    plt.plot(x_new, y_new, color='black', linewidth=1.5, linestyle='-.', label='rate=0.005')
    plt.plot(x_new, y2_new, color='gray', linewidth=1.5, linestyle='--', label='rate=0.02')
    plt.plot(x_new, y3_new, color='black', linewidth=1.5, linestyle='-', label='rate=0.01')
    # 显示图例
    plt.legend()
    plt.xlabel("训练轮数")
    plt.ylabel("loss值")
    plt.show()


draw_loss()