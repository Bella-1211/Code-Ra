from matplotlib import pyplot as plt


def draw_loss():
    x=[]
    y=[]
    y2=[]
    y3=[]
    x_new = []
    y_new = []
    y2_new = []
    y3_new = []
    for i in range(100):
       x.append(i)
    with open('ra.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l1 in line.split():
            y.append(float(l1))
    with open('ra_ran.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l2 in line.split():
            y2.append(float(l2))

    with open('ra_source.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l3 in line.split():
            y3.append(float(l3))

    for i in range(0, len(x), 10):
        x_new.append(x[i])
    for i in range(0, len(y), 10):
        y_new.append(y[i])
    for i in range(0, len(y2), 10):
        y2_new.append(y2[i])
    for i in range(0, len(y3), 10):
        y3_new.append(y3[i])

    y1_new = [9, 5, 11, 18, 5, 11, 12, 13, 14, 3]
    y2_new = [16,9, 14, 32, 11,18, 14, 20, 28,9]
    y3_new = [16,5, 23, 21, 17, 13, 16,13, 28,9]
    y4_new = [11,9, 14, 18, 7, 13,  14,15,20,5]

    y1_new_1 = [3, 5, 5, 9, 11, 11, 12, 13, 14, 18]
    y2_new_1 = [9, 9, 11, 16, 18, 14, 14, 20, 28, 32]
    y3_new_1 = [9, 5, 17, 16, 13, 23, 16, 13, 28, 21]
    y4_new_1 = [5, 9, 7, 11, 13, 14, 14, 15, 20, 18]



    plt.figure(figsize=(6, 4))
    plt.rcParams['xtick.direction']='in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.margins(x=0)
    plt.margins(y=0)
    plt.ylim(0, 50)
    # plt.margins(y2=0)
    # plt.margins(y3=0)
    # plt.subplot(122)
    plt.plot(x_new, y1_new_1, 'ko-', label="本文冗余算法")
    plt.plot(x_new, y2_new_1, 'kp-', label="完全冗余")
    plt.plot(x_new, y3_new_1, 'kd-', label="随机冗余")
    plt.plot(x_new, y4_new_1, 'ks-', label="最小冗余")
    plt.legend()
    plt.xlabel("服务功能链数量")
    plt.ylabel("冗余成本")
    plt.show()


    # sum=0
    # for i in range(len(y)):
    #     sum=sum+y[i]
    # mean=sum/len(y)
    # sum = 0
    # for i in range(len(y2)):
    #     sum = sum + y2[i]
    # mean_ran = sum / len(y2)
    # sum=0
    # for i in range(len(y3)):
    #     sum=sum+y3[i]
    # mean_source=sum/len(y3)
    #
    #
    # x=("本文冗余算法","随机冗余","最小冗余")
    # Y=[mean,mean_ran,mean_source]
    # for a, b in zip(x, Y):  # 柱子上的数字显示
    #     plt.text(a, b, '%.2f' % b, ha='center', va='bottom', fontsize=7);
    # plt.bar(x, Y,color="k",alpha=0.4)
    # # plt.legend()
    # plt.xlabel("服务功能链数量")
    # plt.ylabel("BVNFs所需的平均资源量")
    # plt.show()


draw_loss()