from matplotlib import pyplot as plt


def draw_rate():
    x=[]
    y1=[]
    y2=[]
    y3=[]
    y4=[]
    y5=[]
    y6=[]
    x_new = []
    y1_new = []
    y2_new = []
    y3_new = []
    y4_new = []
    y5_new = []
    y6_new = []

    with open('../time.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l0 in line.split():
            x.append(float(l0))
    with open('rate_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l1 in line.split():
            y1.append(float(l1))
    with open('rate_ra.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l2 in line.split():
            y2.append(float(l2))
    with open('rate_ff_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l3 in line.split():
            y3.append(float(l3))
    with open('rate_ff_ra.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l4 in line.split():
            y4.append(float(l4))
    with open('rate_de_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l5 in line.split():
            y5.append(float(l5))
    with open('rate_de_ra.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l6 in line.split():
            y6.append(float(l6))

    for i in range(0, len(x), 150):
        x_new.append(x[i])
    for i in range(0, len(y1), 150):
        y1_new.append(y1[i])
    for i in range(0, len(y2), 150):
        y2_new.append(y2[i])
    for i in range(0, len(y3), 150):
        y3_new.append(y3[i])
    for i in range(0, len(y4), 150):
        y4_new.append(y4[i])
    for i in range(0, len(y5), 150):
        y5_new.append(y5[i])
    for i in range(0, len(y6), 150):
        y6_new.append(y6[i])

    plt.figure(figsize=(6, 4))
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'
    plt.ylim(0, 1)


    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.margins(x=0)
    plt.margins(y=0)
    # plt.margins(y2=0)
    # plt.margins(y3=0)
    # plt.subplot(122)
    plt.plot(x_new, y1_new, 'ko-', linewidth=1, label="PG")
    plt.plot(x_new, y2_new, 'ko--', label="本文算法")
    plt.plot(x_new, y3_new, 'ks-', label="FF")
    plt.plot(x_new, y4_new, 'ks--', label="FF_RA")
    plt.plot(x_new, y5_new, 'k^-', label="DE")
    plt.plot(x_new, y6_new, 'k^--', label="DE_RA")

    # 显示图例
    plt.legend()
    plt.xlabel("时间")
    plt.ylabel("请求接受率")
    plt.show()


draw_rate()