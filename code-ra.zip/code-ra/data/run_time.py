import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.rc('font', family='Microsoft YaHei')
x_data = ['FF_RA', '本文算法', 'DE_RA']
ax_data = [0.8, 2.9, 0]
ax1_data = [0, 0, 0.17]

fig = plt.figure(dpi=600)
ax = fig.add_subplot(111)

ax.set_ylim([0, 4])
ax.set_yticks = np.arange(0, 4)
ax.set_yticklabels = np.arange(0, 4)

bar_width = 0.2
ax.set_ylabel('运行时间（/ms）');
lns1 = ax.bar(x=np.arange(len(x_data)), width=bar_width, height=ax_data, fc='gray', alpha=0.8)



ax1 = ax.twinx()  # this is the important function

ax1.set_ylim([0, 0.2])
ax1.set_yticks = np.arange(0, 0.2)
ax1.set_yticklabels = np.arange(0, 0.2)
ax1.set_ylabel('运行时间（/s）');
lns2 = ax1.bar(x=np.arange(len(x_data)), width=bar_width, height=ax1_data, fc='black',
               alpha=0.8)


plt.xticks(np.arange(len(x_data)), x_data)

ax.set_xlabel('部署算法')


plt.savefig('run_time.png')  # 图表输出
