import matplotlib.pyplot as plt


plt.figure(figsize=(20, 10), dpi=100)
labels = ['Seq_Ra', 'Seq', 'DE_Ra', 'DE', 'FF_Ra', 'FF']
scores = [23, 0.707, 0.81, 0.7565, 36, 0.5705]
rebounds = [17, 6, 12, 6, 10, 8, 11, 7, 15, 11, 6, 11, 10, 9, 16, 13, 9, 10, 12, 13, 14]
assists = [16, 7, 8, 10, 10, 7, 9, 5, 9, 7, 12, 4, 11, 8, 10, 9, 9, 8, 8, 7, 10]
plt.plot(labels, scores, c='red', label="得分")
plt.plot(labels, rebounds, c='green', linestyle='--', label="篮板")
plt.plot(labels, assists, c='blue', linestyle='-.', label="助攻")
plt.scatter(labels, scores, c='red')
plt.scatter(labels, rebounds, c='green')
plt.scatter(labels, assists, c='blue')
plt.legend(loc='best')
plt.yticks(range(0, 50, 5))
plt.grid(True, linestyle='--', alpha=0.5)
plt.xlabel("部署算法", fontdict={'size': 16})
plt.ylabel("可能能力", fontdict={'size': 16})
plt.show()
