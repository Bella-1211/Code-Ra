from matplotlib import pyplot as plt


def draw_rate():
    x=[]
    y1=[]
    y2=[]
    y3=[]
    y4=[]
    y5=[]
    y6=[]

    with open('../time-fx.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l0 in line.split():
            x.append(float(l0))
    with open('rate_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l1 in line.split():
            y1.append(float(l1))
    # with open('/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_ra.txt') as f:
    #     lines = f.readlines()
    # for line in lines:
    #     for l2 in line.split():
    #         y2.append(float(l2))
    with open('rate_ff_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l3 in line.split():
            y3.append(float(l3))
    # with open('/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_ff_ra.txt') as f:
    #     lines = f.readlines()
    # for line in lines:
    #     for l4 in line.split():
    #         y4.append(float(l4))
    with open('rate_de_.txt') as f:
        lines = f.readlines()
    for line in lines:
        for l5 in line.split():
            y5.append(float(l5))
    # with open('/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_de_ra.txt') as f:
    #     lines = f.readlines()
    # for line in lines:
    #     for l6 in line.split():
    #         y6.append(float(l6))

    plt.figure(figsize=(6, 4))
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'

    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.margins(x=0)
    plt.margins(y=0)
    # plt.margins(y2=0)
    # plt.margins(y3=0)
    # plt.subplot(122)
    print("x", len(x))
    print("y", len(y1))
    plt.plot(x, y1, color='r', linestyle='--', label="本发明方案")
    #plt.plot(x, y2, color='r', linestyle='--')
    plt.plot(x, y3, color='b', linestyle='--', label="遗传算法")
    #plt.plot(x, y4, color='b', linestyle='--')
    plt.plot(x, y5, color='g', linestyle='--', label="首次适应算法")
    #plt.plot(x, y6, color='g', linestyle='--')

    plt.legend()
    plt.xlabel("时间")
    plt.ylabel("请求接受率")
    plt.show()


draw_rate()