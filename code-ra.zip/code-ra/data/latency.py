import matplotlib
import matplotlib.pyplot as plt
import numpy as np


plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']

mean_latency= [0.165, 0.262, 0.252]
mean_succ_latency = [0.163, 0.244, 0.25]
labels = ['本文算法', 'FF_RA', 'DE_RA']

x = np.arange(len(labels))  # the label locations
print(x)
width = 0.2  # the width of the bars


fig, ax = plt.subplots()
rects1 = ax.bar(x - width/2, mean_latency, width, edgecolor="white", color="silver", label='平均时延')
rects2 = ax.bar(x + width/2, mean_succ_latency, width, edgecolor="white", color="gray", label='平均成功时延')

# Add some text for labels, title and custom x-axis tick labels, etc.
# plt.yticks(range(0, 0.3, 0.05))
plt.ylim(0, 0.4)
ax.set_ylabel('时间/ms')
ax.set_xlabel('部署算法')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()






plt.show()
