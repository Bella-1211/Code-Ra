from matplotlib import pyplot as plt


def drawing(x,y):

    plt.figure(figsize=(10, 4))
    plt.margins(x=0)
    plt.margins(y=0)
    #plt.subplot(122)
    plt.plot(x, y, color='r', linestyle='--')
    plt.show()
