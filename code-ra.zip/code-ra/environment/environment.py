import copy
import random
import time
import networkx as nx
import numpy as np
import time as time

from SFCgenerator.event import EventGenerator
#from environment.reward import Reward


#环境，分配资源，释放资源，看能不能成功部署

class Environment(object):
    """
        Implementation of a sequence-to-sequence model based on dyn
        amic multi-cell RNNs

        Attributes:
            num_cpus(int)                           -- Number of hosts
            num_vnfds(int)                          -- Number of VNF descriptors
            env_profile(str)                        -- Environment profile
            dict_vnf_profile(str)                   -- VNF dictionary profile
    """

    def __init__(self):

        # Environment properties
        self.network = self.get_network()
        #self.latency_j=self.get_latency()


    def get_network(self):
        with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abi_node_properties.txt') as f:
            lines = f.readlines()
        graph = nx.Graph()
        node_id=0
        link_id=0
        for line in lines:
            c, x,y,z,h= [float(x) for x in line.split()]
            graph.add_node(node_id, cpu=x, cpu_remain=x,men=y,men_remain=y)  # node_id cpu mem cpu_remain mem_remain
            node_id = node_id + 1

        with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abilene_edge.txt') as f:
            lines = f.readlines()
        for line in lines:
            # from_id, to_id, link_dr, delay, link_dr_reversed, link_delay_reversed = [float(x) for x in line.split()]
            from_id, to_id, bw, delay = [float(x) for x in line.split()]
            graph.add_edge(int(from_id), int(to_id), link_id=link_id, bw=bw, delay=delay, bw_remain=bw)
            link_id = link_id + 1

        return graph

    def get_latency(self):
        latency_j=np.zeros([self.network.number_of_nodes(),self.network.number_of_nodes()])
        with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abilene_edge_min.txt') as f:
            lines = f.readlines()
        for line in lines:
            latency_j[int(line.split()[0]),int(line.split()[1])]=float(line.split()[2])

        print(latency_j)
        return latency_j

    def select_link(self,placement):
        #link=[]
        link_temp=[]
        for i in range(len(placement)-1):
            sn_from = placement[i]
            sn_to = placement[i+1]
            if nx.has_path(self.network, source=sn_from, target=sn_to):
                path =nx.shortest_path(self.network , sn_from, sn_to, weight='delay')
                link_temp.append(path)
        link_num=len(link_temp)
        # for i in range(len(link_temp)):
        #     if i == 0:
        #         for j in range(len(link_temp[i])):
        #             link.append(link_temp[i][j])
        #     else:
        #         j=1
        #         while j<len(link_temp[i]):
        #             link.append((link_temp[i][j]))
        #             j=j+1
        return link_temp,link_num

    def is_successful(self,placement,link,link_num,event,latency,max_latency):
        G1=copy.deepcopy(self.network)
        outcome=0
        for i in range(len(placement)):
            if G1.nodes[placement[i]]['cpu_remain']>=event.nodes[i]['r_cpu']:
                #print(self.network.nodes[placement[i]]['cpu_remain'])
                G1.nodes[placement[i]]['cpu_remain']=G1.nodes[placement[i]]['cpu_remain']-event.nodes[i]['r_cpu']
                #print(self.network.nodes[placement[i]]['cpu_remain'])
                #G1.nodes[placement[i]]['men_remain'] = G1.nodes[placement[i]]['men_remain']-event.nodes[i]['r_men']
            else:
                outcome=1
                break

        if outcome==0:
            #链路
            for i in range(link_num):
                for j in range(len(link[i])-1):
                    if G1.edges[link[i][j],link[i][j+1]]['bw_remain']>=event.edges[i,i+1]['r_bw']:
                        G1.edges[link[i][j],link[i][j+1]]['bw_remain']=G1.edges[link[i][j],link[i][j+1]]['bw_remain']-event.edges[i,i+1]['r_bw']
                    else:
                        outcome=1
                        break

        if outcome==0:
            if latency>max_latency:
                outcome=1
        return outcome


    def assignment(self,placement,link,link_num,event):
        placement=placement
        event=event

        #节点
        for i in range(len(placement)):
            self.network.nodes[placement[i]]['cpu_remain']=self.network.nodes[placement[i]]['cpu_remain']-event.nodes[i]['r_cpu']
            #self.network.nodes[placement[i]]['men_remain'] = self.network.nodes[placement[i]]['men_remain'] - \
             #                                                event.nodes[i]['r_men']
        #链路
        for i in range(link_num):
            for j in range(len(link[i])-1):
                self.network.edges[link[i][j],link[i][j+1]]['bw_remain']=self.network.edges[link[i][j],link[i][j+1]]['bw_remain']-event.edges[i,i+1]['r_bw']

    def release(self,placement,link,link_num,event):
        placement=placement
        event=event

        #节点
        for i in range(len(placement)):
            self.network.nodes[placement[i]]['cpu_remain']=self.network.nodes[placement[i]]['cpu_remain']+event.nodes[i]['r_cpu']
            #self.network.nodes[placement[i]]['men_remain'] = self.network.nodes[placement[i]]['men_remain'] + \
            #                                                 event.nodes[i]['r_men']
        #链路
        for i in range(link_num):
            for j in range(len(link[i])-1):
                self.network.edges[link[i][j],link[i][j+1]]['bw_remain']=self.network.edges[link[i][j],link[i][j+1]]['bw_remain']+event.edges[i,i+1]['r_bw']

    def count_penalty(self,placement,link,link_num,event):
        G2 = copy.deepcopy(self.network)
        penalty_nodes_cpu = []
        #penalty_nodes_men = []
        penalty_edges = []
        penalty_latency=0
        # 节点
        placement = placement
        event = event

        # 节点
        for i in range(len(placement)):
            G2.nodes[placement[i]]['cpu_remain'] = G2.nodes[placement[i]]['cpu_remain'] - event.nodes[i]['r_cpu']
            #G2.nodes[placement[i]]['men_remain'] = G2.nodes[placement[i]]['men_remain'] - event.nodes[i]['r_men']
        for i in range(G2.number_of_nodes()):
            penalty_nodes_cpu.append(G2.nodes[i]['cpu_remain'])
        for i in range(len(penalty_nodes_cpu)):
            if penalty_nodes_cpu[i]>0:
                penalty_nodes_cpu[i]=0
            # if penalty_nodes_men[i]>0:
            #     penalty_nodes_men[i]=0

        # 链路
        for i in range(link_num ):
            for j in range(len(link[i]) - 1):
                G2.edges[link[i][j], link[i][j + 1]]['bw_remain'] = \
                G2.edges[link[i][j], link[i][j + 1]]['bw_remain'] - event.edges[i, i + 1]['r_bw']
        for e in G2.edges():
            penalty_edges.append(G2.edges[e[0],e[1]]['bw_remain'])
        for i in range(len(penalty_edges)):
            if penalty_edges[i]>0:
                penalty_edges[i]=0


        latency=self.count_latency(G2,link,link_num)
        if latency >event.graph['max_latency']:
            penalty_latency=50

        load=self.count_load(G2)

        return penalty_nodes_cpu,penalty_edges,penalty_latency,latency,load


    def count_load(self,G):
        G=G
        load_a=[]
        for i in range(G.number_of_nodes()):
            load_a.append(1-G.nodes[i]['cpu_remain']/G.nodes[i]['cpu'])
        load=np.var(load_a)
        return load

    def count_latency(self,G,link,link_num):
        G=G
        latency=0
        for i in range(link_num-1):
            for j in range(len(link[i])-1):
                latency=latency + G.edges[link[i][j],link[i][j+1]]['delay']
        return latency




if __name__ == "__main__":

    # Define environment
    env=Environment()
    placement=[0,1,2,3]
    event=EventGenerator(2000)
    event.event_generator()
    #reward=Reward(1,0)
    link,link_num=env.select_link(placement)
    outcome=env.is_successful(placement,link,link_num,event.event[0])
    a,b,c,d=env.count_penalty(placement,link,link_num,event.event[0])
    print(a,b)
    print(outcome)
    load=env.count_load(env.network)
    latency=env.count_latency(env.network,link,link_num)
    # reward=reward.reward(latency,load)
    # print(latency,load,reward)




