class Reward(object):

    def __init__(self,parameter1,parameter2):
        # Environment properties
        self.parameter1 = parameter1
        self.parameter2 = parameter2

    def reward(self,latency,load,penalty_nodes_cpu,penalty_edges,penalty_latency):
        penalty_cpu=-sum(penalty_nodes_cpu)*100
        penalty_bw=-sum(penalty_edges)
        reward=self.parameter1*latency+self.parameter2*load+penalty_cpu+penalty_bw+penalty_latency
        return reward