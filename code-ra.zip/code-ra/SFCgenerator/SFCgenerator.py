import numpy as np
from scipy.stats import poisson


#根据泊松分布生成SFC请求文件
class ServiceBatchGenerator(object):

    def __init__(self, batch_size, min_service_length, max_service_length, vocab_size):

        self.mu=0.5
        self.time_size=4000
        self.batch_size = batch_size
        self.min_service_length = min_service_length
        self.max_service_length = max_service_length
        self.vocab_size = vocab_size

        self.service_length = np.zeros(self.batch_size,  dtype='int32')
        self.state = []
        self.r_cpu=[]
        self.r_bw= []
        self.max_latency = np.zeros(self.batch_size,  dtype='int32')
        self.lifetime = np.zeros(self.batch_size, dtype='int32')
        self.arrive_time = np.zeros(self.batch_size, dtype='int32')

    def getNewState(self):
        """ Generate new batch of service chain """
        VNFD_PROPERTIES_SIZE_SMALL = [0, 2, 2, 2, 2, 2, 2, 1, 1]
        VNFD_PROPERTIES_MEN_SMALL = [0, 2, 2, 2, 2, 2, 2, 1, 1]
        VNFD_PROPERTIES_BW_SMALL = [0, 30, 20, 20, 20, 20, 20, 10, 10]
        #生成2000个按照泊松分布到达的sfc
        sum=0
        while sum!=self.batch_size:
            self.time = poisson.rvs(mu=self.mu, size=self.time_size)
            sum=np.sum(self.time)
        SFC_num=0
        for i in range(self.time_size):
            for j in range(self.time[i]):
                self.arrive_time[SFC_num]=i
                SFC_num=SFC_num+1
        #print(self.time,self.arrive_time)

        # Clean attributes
        self.state = []
        self.r_cpu=[]
        self.r_men=[]
        self.r_bw= []
        self.service_length = np.zeros(self.batch_size,  dtype='int32')

        # Compute random services
        for batch in range(self.batch_size):
            self.service_length[batch] = np.random.randint(self.min_service_length, self.max_service_length+1, dtype='int32')
            q_temp=[]
            r_cpu_temp=[]
            r_men_temp=[]
            r_bw_temp = []
            for i in range(self.service_length[batch]):
                id=np.random.randint(1, self.vocab_size,  dtype='int32')
                q_temp.append(id)
                r_cpu_temp.append(VNFD_PROPERTIES_SIZE_SMALL[id])
                r_men_temp.append(VNFD_PROPERTIES_MEN_SMALL[id])
                r_bw_temp.append(VNFD_PROPERTIES_BW_SMALL[id])
            self.state.append(q_temp)
            self.r_cpu.append(r_cpu_temp)
            self.r_men.append(r_men_temp)
            self.r_bw.append(r_bw_temp)

            # 最大允许时延
            max_latency_id = np.random.randint(10, 100,  dtype='int32')
            self.max_latency[batch] = max_latency_id
            #生命周期
            lifetime=np.random.randint(2, 5,  dtype='int32')
            self.lifetime[batch]=lifetime


    def Generate_sequences(self):

        self.getNewState()
        # 将文本写入到text02.txt文件
        for i in range(self.batch_size):
            path = '../SFCrequest/request%d.txt'%i
            with open(path, 'w') as file_read:
                for j in range(len(self.state[i])):
                    file_read.write(str(self.state[i][j])+" ")
                file_read.write("\n%s %s %s %s %s\n"%(len(self.state[i]),len(self.state[i])-1,self.arrive_time[i],self.lifetime[i],self.max_latency[i]))
                for node_n in range(len(self.state[i])):
                    file_read.write("%s %s\n"%(self.r_cpu[i][node_n],self.r_men[i][node_n]))
                for link_n in range(len(self.state[i])-1):
                    file_read.write("%s %s %s\n"%(link_n,link_n+1,self.r_bw[i][link_n]))


    def p(self):
        print(self.state)
        print(self.max_latency)

if __name__ == "__main__":

    # Define generator
    batch_size = 2000
    min_service_length = 2
    max_service_length = 6
    vocab_size = 8

    env = ServiceBatchGenerator(batch_size, min_service_length, max_service_length, vocab_size)
    # env.getNewState()
    # env.p()
    env.Generate_sequences()

