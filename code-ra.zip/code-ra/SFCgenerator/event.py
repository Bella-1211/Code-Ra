import copy
import random

import networkx as nx

from SFCgenerator.redundancy import Redundancy


class EventGenerator(object):
    #事件产生器，根据时间产生SFC的请求和释放事件
    def __init__(self,batch_size):
        self.batch_size=batch_size
        self.event=[]
        self.path="/home/fx/文档/文献/本人/第二篇/code-r/code/SFCrequest/"
        self.Ra=Redundancy()

    #读取文件中的SFC信息
    def read_SFC(self,file_name,i):
        global vgraph
        vgraph = nx.Graph()
        node_id, link_id = 0, 0
        SFC=[]

        with open(self.path + file_name) as f:
            lines = f.readlines()
        for i in lines[0].split():
            SFC.append(int(i))
        node_num, link_num, arrive_time, life_time, max_latency = [int(x) for x in lines[1].split()]
        sfc_graph = nx.Graph(type=0, arrive_time=arrive_time, life_time=life_time,id=i,SFC=SFC,max_latency=max_latency)


        for line in lines[2:node_num + 2]:
            r= [float(x) for x in line.split()]
            sfc_graph.add_node(node_id,r_cpu=r[0],r_men=r[1])
            node_id = node_id + 1

        for line in lines[-link_num:]:
            src, dst, r_bw = [float(x) for x in line.split()]
            sfc_graph.add_edge(int(src), int(dst), link_id=link_id, r_bw=r_bw)
            link_id = link_id + 1
        return sfc_graph


    #创建事件
    def event_generator(self):
        for i in range(self.batch_size):
            filename = 'request%d.txt' % i
            req_arrive = self.read_SFC(filename,i)
            req_arrive.graph['id'] = i
            req_leave = copy.deepcopy(req_arrive)
            # type 是指 表示请求已经读取
            req_leave.graph['type'] = 1
            req_leave.graph['arrive_time'] = req_arrive.graph['arrive_time'] + req_arrive.graph['life_time']
            self.event.append(req_arrive)
            self.event.append(req_leave)
        # 按照时间（到达时间或离开时间）对这些请求从小到大进行排序
        self.event.sort(key=lambda r: r.graph['arrive_time'])


    def read_SFC_ra(self,file_name,i):
        global vgraph
        vgraph = nx.Graph()
        node_id, link_id = 0, 0
        SFC=[]

        with open(self.path + file_name) as f:
            lines = f.readlines()
        for i in lines[0].split():
            SFC.append(int(i))
        node_num, link_num, arrive_time, life_time, max_latency = [int(x) for x in lines[1].split()]


        vnfr=self.Ra.Ra_generator(node_num)
        sfc_qr=self.Ra.Ra_SFC_generator()
        vnfr_t,SFC_r=self.Ra.redundancy_determination(SFC,vnfr,sfc_qr)
        SFCr=[]
        for i in range(len(SFC_r)):
            for j in range(vnfr_t[i]):
                SFCr.append(SFC_r[i][0])
        SFC_R=self.Ra.reliability_count(node_num,vnfr,vnfr_t)

        sfc_graph = nx.Graph(type=0, arrive_time=arrive_time, life_time=life_time, id=i, SFC=SFCr,
                             max_latency=max_latency,vnfr_t=vnfr_t,sfc_qr=sfc_qr,SFC_R=SFC_R,vnfr=vnfr)

        n = 0
        for line in lines[2:node_num + 2]:

            r= [float(x) for x in line.split()]
            for i in range(vnfr_t[n]):
                sfc_graph.add_node(node_id,r_cpu=r[0],r_men=r[1])
                node_id = node_id + 1
            n=n+1

        num_l=0
        m = 0
        for line in lines[-link_num:]:
            src, dst, r_bw = [float(x) for x in line.split()]

            for i in range(vnfr_t[m]):
                sfc_graph.add_edge(num_l, num_l+1, link_id=link_id, r_bw=r_bw)
                num_l=num_l+1
                link_id = link_id + 1


            m = m + 1

        if vnfr_t[m] > 1:
            for i in range(vnfr_t[m] - 1):
                sfc_graph.add_edge(num_l, num_l + 1, link_id=link_id, r_bw=r_bw)
                num_l = num_l + 1
                link_id = link_id + 1
        return sfc_graph


    def event_generator_ra(self):
        for i in range(self.batch_size):
            filename = 'request%d.txt' % i
            req_arrive = self.read_SFC_ra(filename,i)
            req_arrive.graph['id'] = i
            req_leave = copy.deepcopy(req_arrive)
            # type 是指 表示请求已经读取
            req_leave.graph['type'] = 1
            req_leave.graph['arrive_time'] = req_arrive.graph['arrive_time'] + req_arrive.graph['life_time']
            self.event.append(req_arrive)
            self.event.append(req_leave)
        # 按照时间（到达时间或离开时间）对这些请求从小到大进行排序
        self.event.sort(key=lambda r: r.graph['arrive_time'])

if __name__ == "__main__":

    # Define generator
    env=EventGenerator(2000)
    env.event_generator()
    print(env.event[0].nodes[0])
    print(env.event[0].edges[0,1])
    print(env.event[0].graph['max_latency'])
