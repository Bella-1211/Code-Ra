import random

import numpy as np


class Redundancy(object):

    def __init__(self):
        self.VNF_S=[0, 2, 2, 2, 2, 2, 2, 1, 1]


    def reliability_count(self,L,VNF_R,vnfr):
        #计算可靠性
        R=[0]*L
        r=1
        for i in range(L):
            f=1- VNF_R[i]
            f1=f** vnfr[i]
            R[i]=1-f1
        for i in range(L):
            r=r*R[i]
        return r


    def reliability_increase(self,SFC,L, VNF_R, vnfr):
        r_p=[0]*L
        r_i= self.reliability_count( L, VNF_R, vnfr)
        r_f=[0]*L
        r_o=[0]*L
        vnfr_t=vnfr
        for i in range(L):
            vnfr_t[i]=vnfr_t[i]+1
            r_p[i]= self.reliability_count(L, VNF_R, vnfr_t)
            vnfr_t[i]=vnfr_t[i]-1
        for i in range(L):
            r_f[i]=r_p[i]-r_i
        for i in range(L):
            r_o[i]= r_f[i] / self.VNF_S[SFC[i]]
        r_max=max(r_o)
        a=r_o.index(r_max)  #冗余VNF在链上的位置
        return r_f,r_p,r_i,r_o,a



    def redundancy_determination(self,SFC, VNF_R,theta):  #链，VNF的可靠性，VNF初始冗余,要求的可靠性
        L=len(SFC)
        SFC_r=[]
        SFC_R=[]
        vnfr_t = np.ones(L,dtype=int)
        r_t = self.reliability_count(L, VNF_R, vnfr_t)

        while r_t < theta:
            r_f, r_p, r_i, r_o, a = self.reliability_increase(SFC, L, VNF_R, vnfr_t)
            vnfr_t[a] = vnfr_t[a] + 1
            r_t = self.reliability_count( L, VNF_R, vnfr_t)
        for i in range(L):
            for j in range(vnfr_t[i]):
                SFC_r.append(SFC[i])
            SFC_R.append(SFC_r)
            SFC_r=[]

        return vnfr_t,SFC_R


    def Ra_generator(self,L):
        ra=[]
        for i in range(L):
            ra.append(random.uniform(0.9,1.0))
        return ra

    def Ra_SFC_generator(self):
        ra_SFC=random.uniform(0.95,0.99)
        return ra_SFC

if __name__ == '__main__':
    SFC=[1,2,3]

    R=Redundancy()
    SFC_R=R.Ra_generator(len(SFC))
    print("SFC_R",SFC_R)
    theta=R.Ra_SFC_generator()
    a,b=R.redundancy_determination(SFC,SFC_R,theta)

    print(theta)
    print(a,b)