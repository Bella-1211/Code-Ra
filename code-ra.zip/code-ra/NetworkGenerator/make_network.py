import math
import random

import networkx as nx
import os
import matplotlib.pyplot as plt

#读取网络节点，保存经纬度
def network_node():
    file="../network/Abi_node.txt"
    G=nx.read_graphml('../network_g/Abilene.graphml')
    for node in G.nodes(data=True):
        with open(file,mode="a") as f:

            f.write("%s %s %s\n"%(node[0],node[1]['Latitude'],node[1]['Longitude']))

#生成节点属性
def network_node_properties():
    file= "../network/Abi_node_properties.txt"
    with open(file,'a') as f:
        for i in range(11):
            num=i
            cpu=random.randint(4,5)
            men=random.randint(4,5)
            bw=random.randint(5,6)*100
            lat=random.uniform(100,180)
            f.write("%s %s %s %s %f\n"%(num,cpu,men,bw,lat))
            node_edge = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
        for i in node_edge:
            num = i
            cpu = 4
            men = 4
            bw = random.randint(5, 6) * 100
            lat = random.uniform(100, 180)
            f.write("%s %s %s %s %f\n" % (num, cpu, men, bw, lat))

#根据经纬度求距离
def haversine(lat1, lon1, lat2, lon2):
    # distance between latitudes
    # and longitudes
    dLat = (lat2 - lat1) * math.pi / 180.0
    dLon = (lon2 - lon1) * math.pi / 180.0

    # convert to radians
    lat1 = (lat1) * math.pi / 180.0
    lat2 = (lat2) * math.pi / 180.0

    # apply formulae
    a = (pow(math.sin(dLat / 2), 2) +
         pow(math.sin(dLon / 2), 2) *
         math.cos(lat1) * math.cos(lat2));
    rad = 6371
    c = 2 * math.asin(math.sqrt(a))
    return rad * c


#生成节点之间距离
def network_edge():
    file = "../network/Abilene_edge.txt"
    G = nx.read_graphml('../network_g/Abilene.graphml')
    for edge in G.edges(data=True):
        n1 = G.nodes(data=True)[edge[0]]
        n2 = G.nodes(data=True)[edge[1]]
        n1_lat, n1_long = n1.get("Latitude"), n1.get("Longitude")
        n2_lat, n2_long = n2.get("Latitude"), n2.get("Longitude")
        distance = haversine(n1_lat, n1_long, n2_lat, n2_long)
        bw =random.randint(800,1000)
        lency=distance / 299792.458
        lency=lency*1000
        a=int(edge[0])
        b=int(edge[1])
        with open(file, mode="a") as f:
            f.write("%s %s %f %f \n" % (a, b,bw,lency))
    j=0
    n=0
    for i in range(11):
        with open(file, mode="a") as f:
            bw_1 = random.randint(500, 800)
            bw_2 = random.randint(500, 800)
            lency_1=2
            lency_2 =0.25
            f.write("%s %s %f %f \n" % (2*i+11, i,bw_1,lency_1))
            f.write("%s %s %f %f \n" % (2*i + 12, i, bw_1, lency_1))
            f.write("%s %s %f %f \n" % (2*i + 11, 2*i+12, bw_2, lency_2))
        j=j+1
        if j%2==0:
            n=n+1

#读取节点链路信息
def get_substrate_list(t):
    CPU_PROPERTIES_CPU= []
    CPU_PROPERTIES_LAT = []
    CPU_PROPERTIES_BW=[]
    t=t
    if t=="S":
        f = open('network/Ntt_node_properties.txt')
    elif t=="G":
        f = open('network/Ntt_node_properties.txt')
    lines = f.readlines()
    for line in lines:
        CPU_PROPERTIES_CPU.append(int(line.split(" ")[1]))
        CPU_PROPERTIES_BW.append(int(line.split(" ")[2]))
        CPU_PROPERTIES_LAT.append(float(line.split(" ")[3]))
    return CPU_PROPERTIES_CPU,CPU_PROPERTIES_BW,CPU_PROPERTIES_LAT

def get_link_min():
    with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abi_node_properties.txt') as f:
        lines = f.readlines()
    G = nx.Graph()
    node_id = 0
    link_id = 0
    for line in lines:
        c, x, y, z, h = [float(x) for x in line.split()]
        G.add_node(node_id, cpu=x, cpu_remain=x, men=y, men_remain=y)  # node_id cpu mem cpu_remain mem_remain
        node_id = node_id + 1

    with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abilene_edge.txt') as f:
        lines = f.readlines()
    for line in lines:
        # from_id, to_id, link_dr, delay, link_dr_reversed, link_delay_reversed = [float(x) for x in line.split()]
        from_id, to_id, bw, delay = [float(x) for x in line.split()]
        G.add_edge(int(from_id), int(to_id), link_id=link_id, bw=bw, delay=delay, bw_remain=bw)
        link_id = link_id + 1

    with open('/home/fx/文档/文献/本人/第二篇/code-ra/network/Abilene_edge_min.txt', mode="a") as f:
        for i in range(33):
            for j in range(33):
                latency = 0
                if nx.has_path(G, source=i, target=j):
                    path =nx.shortest_path(G , i, j, weight='delay')
                if len(path)==1:
                    latency=0
                else:
                    for x in range(len(path) - 1):
                        latency = latency + G.edges[path[x], path[x+1]]['delay']

                f.write("%s %s %f \n" % (i, j,latency))


if __name__ == "__main__":
    #network_node()
   # network_edge()
    #network_node_properties()
    get_link_min()