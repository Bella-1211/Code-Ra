import copy
import os
import random
import time
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical

import Drawing
from SFCgenerator.event import EventGenerator
from SFCgenerator.redundancy import Redundancy
from environment.environment import Environment
from environment.reward import Reward
from model.model import Actor


class PgSeq2SeqSolver(object):
    """
    A Reinforcement Learning-based solver that uses
    Policy Gradient (PG) as the training algorithm and
    Sequence-to-Sequence (Seq2Seq) as the neural network model.
    """
    def __init__(self):
        feature_dim = 3  # (n_attrs, e_attrs, dist, degree)
        action_dim = 33
        self.batch_size=1000
        self.lr_actor=0.005
        self.softmax_temp=1
        self.device="cuda"
        self.policy = Actor(feature_dim, action_dim).to(self.device)
        self.optimizer = torch.optim.Adam([
            {'params': self.policy.parameters(), 'lr': self.lr_actor},
        ])
        self.preprocess_obs = obs_as_tensor
        self.env=Environment()
        self.reward=Reward(0,0)
        self.event=EventGenerator(2000)
        self.Ra = Redundancy()
        self.record_batch = {"loss": []}
        self.record={"placement":[],"link":[],"probs":[],"reward":[],"fail":[],"time":[],"rate":[],"loss":[]}
        self.degree=[]
        for i in range(self.env.network.number_of_nodes()):
            self.degree.append(self.env.network.degree[i])

    def deplay(self):
        self.policy.load_state_dict(torch.load("/home/fx/文档/文献/本人/第二篇/code-ra/save/save_data_0.01.pkl"))
        self.policy.eval()

        self.event.event_generator()
        number=0
        number_su=0
        num_latency=0
        num_l=0
        for j in range(len(self.event.event)):

            if self.event.event[j].graph['type'] == 0:
                number = number + 1


                placement= self.solve_deplay(self.event.event[j].number_of_nodes())  # 生成放置位置

                vnfr=self.Ra.Ra_generator(self.event.event[j].number_of_nodes())
                Ra=1
                for i in range(len(vnfr)):
                    Ra=Ra*vnfr[i]
                if random.random() > Ra:
                    finall_f=1
                else:
                    finall_f=0

                if finall_f==0:
                    self.record["placement"].append(placement)
                    #print(placement)
                    link, link_num = self.env.select_link(placement)  # 生成链路
                    self.record["link"].append(link)
                    latency = self.env.count_latency(self.env.network, link, link_num)
                    max_latency=self.event.event[j].graph['max_latency']
                    outcome=self.env.is_successful(placement,link,link_num,self.event.event[j],latency,max_latency)#判断是否成功
                    #print("outcpme:",outcome)
                    if outcome == 0:
                        number_su=number_su+1
                        self.env.assignment(placement, link, link_num, self.event.event[j])  # 分配资源
                        latency=self.env.count_latency(self.env.network,link,link_num)
                        load = self.env.count_load(self.env.network)
                        num_l=num_l+1
                        penalty_nodes, penalty_edges,penalty_latency=[0,0],[0,0],0
                    else:
                        # penalty_nodes, penalty_edges, latency, load = self.env.count_penalty(placement, link, link_num,
                        #                                                                      self.event.event[
                        #                                                                          j])  # 计算惩罚
                        latency = self.env.count_latency(self.env.network, link, link_num)
                        if latency > self.event.event[j].graph['max_latency']:
                            penalty_latency = 50
                            num_latency = num_latency + 1
                        penalty_nodes, penalty_edges=[50,50],[50,50]



                        load = self.env.count_load(self.env.network)
                        self.record["fail"].append(self.event.event[j].graph["id"])

                    reward = self.reward.reward(latency, load, penalty_nodes, penalty_edges,penalty_latency)  # 计算最终奖励
                    self.record["reward"].append(reward)  # 记录
                else:
                    self.record["placement"].append(placement)
                    self.record["link"].append([])
                    self.record["fail"].append(self.event.event[j].graph["id"])
                if number == 1:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su / number)
                elif self.record["time"][len(self.record["time"])-1] != self.event.event[j].graph['arrive_time']:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su/number)


            elif self.event.event[j].graph['type'] == 1:
                id = self.event.event[j].graph['id']
                # print("id",id)
                if id not in self.record["fail"]:
                    placement = self.record["placement"][id]
                    link_r = self.record["link"][id]
                    # print(link_r)
                    self.env.release(placement, link_r, len(link_r), self.event.event[j])  # 释放
            else:
                print("错误")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_.txt'
        with open(path, 'w') as file_read:
            for i in range(len(self.record["rate"])):
                file_read.write(str(float(self.record["rate"][i])) + " ")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/latency/latency_.txt'
        with open(path, 'w') as file_read:
            file_read.write(str(num_latency/(num_latency+num_l)))

        Drawing.drawing( self.record["time"],self.record["rate"])

    def deplay_ra(self):
        self.policy.load_state_dict(torch.load("/home/fx/文档/文献/本人/第二篇/code-ra/save/save_data_0.01.pkl"))
        self.policy.eval()

        self.event.event_generator()
        number=0
        number_su=0
        num_latency=0
        num_l=0
        for j in range(len(self.event.event)):

            if self.event.event[j].graph['type'] == 0:
                number = number + 1

                sfc_q_ra=self.Ra.Ra_SFC_generator()   #冗余
                vnf_r=self.Ra.Ra_generator(self.event.event[j].number_of_nodes())
                vnfr_t, SFC_R=self.Ra.redundancy_determination(self.event.event[j].graph['SFC'],vnf_r,sfc_q_ra)

                placement, finall_f= self.solve_deplay_ra(self.event.event[j].number_of_nodes(),vnf_r, SFC_R)  # 生成放置位置
                if finall_f==0:
                    self.record["placement"].append(placement)
                    #print(placement)
                    link, link_num = self.env.select_link(placement)  # 生成链路
                    self.record["link"].append(link)
                    latency = self.env.count_latency(self.env.network, link, link_num)
                    max_latency=self.event.event[j].graph['max_latency']
                    outcome=self.env.is_successful(placement,link,link_num,self.event.event[j],latency,max_latency)#判断是否成功
                    #print("outcpme:",outcome)
                    if outcome == 0:
                        number_su=number_su+1
                        self.env.assignment(placement, link, link_num, self.event.event[j])  # 分配资源
                        latency=self.env.count_latency(self.env.network,link,link_num)
                        load = self.env.count_load(self.env.network)

                        num_l=num_l+1

                        penalty_nodes, penalty_edges,penalty_latency=[0,0],[0,0],0
                    else:
                        # penalty_nodes, penalty_edges, latency, load = self.env.count_penalty(placement, link, link_num,
                        #                                                                      self.event.event[
                        #                                                                          j])  # 计算惩罚
                        latency = self.env.count_latency(self.env.network, link, link_num)
                        if latency > self.event.event[j].graph['max_latency']:
                            penalty_latency = 50
                            num_latency = num_latency + 1
                        penalty_nodes, penalty_edges=[50,50],[50,50]



                        load = self.env.count_load(self.env.network)
                        self.record["fail"].append(self.event.event[j].graph["id"])

                    reward = self.reward.reward(latency, load, penalty_nodes, penalty_edges,penalty_latency)  # 计算最终奖励
                    self.record["reward"].append(reward)  # 记录
                else:
                    self.record["placement"].append(placement)
                    self.record["link"].append([])
                    self.record["fail"].append(self.event.event[j].graph["id"])
                if number == 1:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su / number)
                elif self.record["time"][len(self.record["time"])-1] != self.event.event[j].graph['arrive_time']:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su/number)


            elif self.event.event[j].graph['type'] == 1:
                id = self.event.event[j].graph['id']
                # print("id",id)
                if id not in self.record["fail"]:
                    placement = self.record["placement"][id]
                    link_r = self.record["link"][id]
                    # print(link_r)
                    self.env.release(placement, link_r, len(link_r), self.event.event[j])  # 释放
            else:
                print("错误")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_ra.txt'
        with open(path, 'w') as file_read:
            for i in range(len(self.record["rate"])):
                file_read.write(str(float(self.record["rate"][i])) + " ")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/latency/latency_ra.txt'
        with open(path, 'w') as file_read:
            file_read.write(str(num_latency/(num_latency+num_l)))

        Drawing.drawing( self.record["time"],self.record["rate"])


    def learn(self):
        self.event.event_generator()


        for i in range(self.batch_size):
            print(i)
            m, n, o, p = 0, 0, 0, 0
            for j in range(len(self.event.event)):
                #print(j)
                if self.event.event[j].graph['type']==0:
                    m=m+1
                    placement=self.solve(self.event.event[j].number_of_nodes())#生成放置位置
                    self.record["placement"].append(placement)
                    link,link_num=self.env.select_link(placement)#生成链路
                    self.record["link"].append(link)
                    # print(self.env.network.nodes[0]['cpu_remain'],self.env.network.nodes[1]['cpu_remain'],self.env.network.nodes[2]['cpu_remain'],
                    #       self.env.network.nodes[3]['cpu_remain'])
                    latency = self.env.count_latency(self.env.network, link, link_num)
                    max_latency=self.event.event[j].graph['max_latency']
                    outcome=self.env.is_successful(placement,link,link_num,self.event.event[j],latency,max_latency)#判断是否成功
                    # print(self.env.network.nodes[0]['cpu_remain'], self.env.network.nodes[1]['cpu_remain'],
                    #       self.env.network.nodes[2]['cpu_remain'],
                    #       self.env.network.nodes[3]['cpu_remain'])
                    #print("outcpme:", outcome)
                    if outcome == 0:
                        o=o+1
                        self.env.assignment(placement, link, link_num, self.event.event[j])  # 分配资源
                        latency = self.env.count_latency(self.env.network, link, link_num)
                        load = self.env.count_load(self.env.network)

                        penalty_nodes, penalty_edges, penalty_latency = [0, 0], [0, 0], 0
                    else:
                        # penalty_nodes, penalty_edges, latency, load = self.env.count_penalty(placement, link, link_num,
                        #                                                                      self.event.event[
                        #                                                                          j])  # 计算惩罚
                        latency = self.env.count_latency(self.env.network, link, link_num)
                        if latency > self.event.event[j].graph['max_latency']:
                            penalty_latency = 10
                        penalty_nodes, penalty_edges= [5, 5], [5, 5]

                        load = self.env.count_load(self.env.network)
                        self.record["fail"].append(self.event.event[j].graph["id"])

                    reward = self.reward.reward(latency, load, penalty_nodes, penalty_edges, penalty_latency)  # 计算最终奖励
                    self.record["reward"].append(reward)  # 记录

                elif self.event.event[j].graph['type']==1:
                    n=n+1
                    id=self.event.event[j].graph['id']
                    #print("id",id)
                    if id not in self.record["fail"]:
                        p=p+1
                        placement=self.record["placement"][id]
                        link_r=self.record["link"][id]
                        #print(link_r)
                        self.env.release(placement,link_r,len(link_r),self.event.event[j])#释放
                else:
                    print("错误")

            self.updata()#更新参数
            print(m,n,o,p)
        torch.save(self.policy.state_dict(),"/home/fx/文档/文献/本人/第二篇/code-ra/save/save_data_0.01.pkl")

        path = '/data/loss/loss_0.01.txt'
        with open(path, 'w') as file_read:
            for i in range(len(self.record_batch["loss"])):
                file_read.write(str(float(self.record_batch["loss"][i])) + " ")


    def select_action(self,observation):
        action_logits = self.policy.act(observation)
        action_probs = F.softmax(action_logits / self.softmax_temp, dim=-1)
        candicate_action_dist = Categorical(probs=action_probs)
        action = candicate_action_dist.sample()
        action_logprob = candicate_action_dist.log_prob(action)
        return action,action_logprob



    def x_generate(self,G):
        G=G
        x = np.zeros([G.number_of_nodes(), 3], dtype='float32')
        cpu_remain=np.zeros(G.number_of_nodes())
        bw_remain_sum =np.zeros(G.number_of_nodes())
        for i in range(G.number_of_nodes()):
            cpu_remain[i]=G.nodes[i]['cpu_remain']
            bw_remain=list(G.edges(i))
            for j in range(len(bw_remain)):
                bw_remain_sum[i] = bw_remain_sum[i] +G.edges[bw_remain[j][0],bw_remain[j][1]]["bw_remain"]
        for i in range(len(cpu_remain)):
            x[i][0]=cpu_remain[i]
            x[i][1]=bw_remain_sum[i]
            x[i][2]=self.degree[i]


        return x

    def solve(self,long):
        G=copy.deepcopy(self.env.network)
        placement=[]
        x=[self.x_generate(G)]
        device="cuda"
        x=np.array(x)
        x=torch.tensor(x).to(device)
        # sub env for sub agent
        sub_done = False
        outputs = self.policy.encode(x)
        p_node_id = G.number_of_nodes()
        for i in range(long):
            hidden_state, cell_state = self.policy.get_last_rnn_state()
            #print("hidden_state, cell_state",hidden_state.shape, cell_state.shape)
            sub_obs = {
                'p_node_id': p_node_id,
                'hidden_state': np.squeeze(hidden_state.cpu().detach().numpy(), axis=0),
                'cell_state': np.squeeze(cell_state.cpu().detach().numpy(), axis=0),
            }
            tensor_sub_obs = self.preprocess_obs(sub_obs, device=self.device)
            action, action_logprob = self.select_action(tensor_sub_obs)
            self.record["probs"].append(action_logprob)
            #print("action_logprob",action_logprob)
            p_node_id = action[0].item()
            id=int(p_node_id)

            placement.append(id)

        return placement

    def solve_deplay(self,long):
        G=copy.deepcopy(self.env.network)
        placement=[]
        x=[self.x_generate(G)]
        device="cuda"
        x=np.array(x)
        x=torch.tensor(x).to(device)
        # sub env for sub agent
        sub_done = False
        outputs = self.policy.encode(x)
        p_node_id = G.number_of_nodes()

        for i in range(long):

            hidden_state, cell_state = self.policy.get_last_rnn_state()
            #print("hidden_state, cell_state",hidden_state.shape, cell_state.shape)
            sub_obs = {
                'p_node_id': p_node_id,
                'hidden_state': np.squeeze(hidden_state.cpu().detach().numpy(), axis=0),
                'cell_state': np.squeeze(cell_state.cpu().detach().numpy(), axis=0),
            }
            tensor_sub_obs = self.preprocess_obs(sub_obs, device=self.device)
            action, action_logprob = self.select_action(tensor_sub_obs)
            self.record["probs"].append(action_logprob)
            #print("action_logprob",action_logprob)
            p_node_id = action[0].item()
            id=int(p_node_id)
            placement.append(id)


        return placement

    def solve_deplay_ra(self,long,vnf_r, SFC_R):
        G=copy.deepcopy(self.env.network)
        placement=[]
        x=[self.x_generate(G)]
        device="cuda"
        x=np.array(x)
        x=torch.tensor(x).to(device)
        # sub env for sub agent
        sub_done = False
        outputs = self.policy.encode(x)
        p_node_id = G.number_of_nodes()
        failure=0
        final_f=0
        for i in range(long):
            for j in range(len(SFC_R[i])):
                hidden_state, cell_state = self.policy.get_last_rnn_state()
                #print("hidden_state, cell_state",hidden_state.shape, cell_state.shape)
                sub_obs = {
                    'p_node_id': p_node_id,
                    'hidden_state': np.squeeze(hidden_state.cpu().detach().numpy(), axis=0),
                    'cell_state': np.squeeze(cell_state.cpu().detach().numpy(), axis=0),
                }
                tensor_sub_obs = self.preprocess_obs(sub_obs, device=self.device)
                action, action_logprob = self.select_action(tensor_sub_obs)
                self.record["probs"].append(action_logprob)
                #print("action_logprob",action_logprob)
                p_node_id = action[0].item()
                id=int(p_node_id)

                if random.random()<vnf_r[i]:  #是否失效
                    placement.append(id)
                    break
                if j ==len(SFC_R[i])-1:
                    failure=1
            if failure == 1:
                final_f=1
                break

        return placement , final_f

    def updata(self):
        loss=self.compute_loss()
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.clear_record()
    def compute_loss(self):
        reward = []
        loss=0
        for i in range(len(self.record["placement"])):
            for j in range(len(self.record["placement"][i])):
                reward.append(self.record["reward"][i])
        #print(reward)
        for i in range(len(reward)):
            loss=loss+self.record["probs"][i]*reward[i]
        loss=-loss/2000
        print("loss",float(loss))
        self.record_batch["loss"].append(float(loss))
        return loss

    def clear_record(self):
        self.record = {"placement": [], "link": [], "probs": [], "reward": [], "fail": []}

def obs_as_tensor(obs, device):
    # one
    if isinstance(obs, dict):
        """Preprocess the observation to adapte to batch mode."""
        obs_p_node_id = torch.LongTensor([obs['p_node_id']]).to(device)
        obs_hidden_state = torch.FloatTensor(obs['hidden_state']).unsqueeze(dim=1).to(device)
        obs_cell_state = torch.FloatTensor(obs['cell_state']).unsqueeze(dim=1).to(device)
        return {'p_node_id': obs_p_node_id, 'hidden_state': obs_hidden_state, 'cell_state': obs_cell_state}
    # batch
    elif isinstance(obs, list):
        obs_batch = obs
        p_node_id_list, hidden_state_list, cell_state_list = [], [], []
        for observation in obs_batch:
            p_node_id_list.append(observation['p_node_id'])
            hidden_state_list.append(observation['hidden_state'])
            cell_state_list.append(observation['cell_state'])
        obs_p_node_id = torch.LongTensor(np.array(p_node_id_list)).to(device)
        obs_hidden_state = torch.FloatTensor(np.array(hidden_state_list)).permute(1, 0, 2).to(device)
        obs_cell_state = torch.FloatTensor(np.array(cell_state_list)).permute(1, 0, 2).to(device)
        return {'p_node_id': obs_p_node_id, 'hidden_state': obs_hidden_state, 'cell_state': obs_cell_state}
    else:
        raise ValueError('obs type error')
