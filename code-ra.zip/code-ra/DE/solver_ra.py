import copy
import random

import networkx as nx
import numpy as np
import geatpy as ea

from DE.environment import MyProblem
from SFCgenerator.event import EventGenerator
from SFCgenerator.redundancy import Redundancy
from environment.environment import Environment

from environment.reward import Reward
import Drawing


class DE_r(object):

    def __init__(self):
        self.env=Environment()
        self.reward=Reward(0,1)
        self.event=EventGenerator(2000)
        self.record={"placement":[],"link":[],"probs":[],"reward":[],"fail":[],"time":[],"rate":[]}
        self.Ra=Redundancy()

    def deplay(self):

        self.event.event_generator_ra()
        number = 0
        number_su = 0
        num_latency=0
        num_l=0
        for j in range(4000):

            if self.event.event[j].graph['type'] == 0:
                number = number + 1
                SFC = self.event.event[j].graph['SFC']
                placement = self.solve(j, SFC)  # 生成放置位置
                self.record["placement"].append(placement)
                # print(placement)
                link, link_num = self.env.select_link(placement)  # 生成链路
                self.record["link"].append(link)
                latency = self.env.count_latency(self.env.network, link, link_num)
                outcome = self.env.is_successful(placement, link, link_num, self.event.event[j], latency,
                                                 self.event.event[j].graph['max_latency'])  # 判断是否成功
                print("outcome", outcome)
                if random.random() > self.event.event[j].graph['SFC_R']:
                    outcome = 1
                # print("outcpme:",outcome)
                if outcome == 0:
                    number_su = number_su + 1
                    self.env.assignment(placement, link, link_num, self.event.event[j])  # 分配资源
                    num_l=num_l+1
                    load = self.env.count_load(self.env.network)
                    penalty_nodes, penalty_edges, penalty_latency = [0, 0], [0, 0], 0
                else:
                    penalty_nodes, penalty_edges = [50, 50], [50, 50]
                    latency = self.env.count_latency(self.env.network, link, link_num)
                    num_latency=num_latency+1
                    if latency > self.event.event[j].graph['max_latency']:
                        penalty_latency = 50
                    else:
                        penalty_latency = 0
                    load = self.env.count_load(self.env.network)
                    self.record["fail"].append(self.event.event[j].graph["id"])

                reward = self.reward.reward(latency, load, penalty_nodes, penalty_edges, penalty_latency)  # 计算最终奖励
                self.record["reward"].append(reward)  # 记录
                if number == 1:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su / number)
                elif self.record["time"][len(self.record["time"]) - 1] != self.event.event[j].graph['arrive_time']:
                    self.record["time"].append(self.event.event[j].graph['arrive_time'])
                    self.record["rate"].append(number_su / number)


            elif self.event.event[j].graph['type'] == 1:
                id = self.event.event[j].graph['id']
                # print("id",id)
                if id not in self.record["fail"]:
                    placement = self.record["placement"][id]
                    link_r = self.record["link"][id]
                    # print(link_r)
                    self.env.release(placement, link_r, len(link_r), self.event.event[j])  # 释放
            else:
                print("错误")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/rate/rate_de_ra.txt'
        with open(path, 'w') as file_read:
            for i in range(len(self.record["rate"])):
                file_read.write(str(float(self.record["rate"][i])) + " ")

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/latency/latency_de_ra.txt'
        with open(path, 'w') as file_read:
            file_read.write(str(num_latency / (num_latency + num_l)))

        path = '/home/fx/文档/文献/本人/第二篇/code-ra/data/time.txt'
        with open(path, 'w') as file_read:
            for i in range(len(self.record["time"])):
                file_read.write(str(int(self.record["time"][i])) + " ")

        Drawing.drawing(self.record["time"], self.record["rate"])

    def solve(self, j, SFC):
        problem = MyProblem(33, self.env.network, self.event.event[j], SFC)
        # 构建算法
        algorithm = ea.soea_DE_rand_1_bin_templet(
            problem,
            ea.Population(Encoding='RI', NIND=4),
            MAXGEN=20,  # 最大进化代数。
            logTras=0)  # 表示每隔多少代记录一次日志信息，0表示不记录。
        algorithm.mutOper.F = 0.9  # 差分进化中的参数F
        algorithm.recOper.XOVR = 0.5  # 重组概率
        # 求解
        res = ea.optimize(algorithm, verbose=False, drawing=0, outputMsg=True, drawLog=False, saveFlag=False)
        return res["Vars"][0]


    def clear_record(self):
        self.record = {"placement": [], "link": [], "probs": [], "reward": [], "fail": []}

if __name__ == '__main__':
    de=DE_r()
    de.deplay()
