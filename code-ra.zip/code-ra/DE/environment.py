import copy

import networkx as nx
import numpy as np
import geatpy as ea


class MyProblem(ea.Problem):  # 继承Problem父类

    def __init__(self,cpu_num,G,event,SFC):
        name = 'MyProblem'  # 初始化name（函数名称，可以随意设置）
        M = 1             # 初始化M（目标维数）
        maxormins = [1]  # 初始化maxormins（目标最小最大化标记列表，1：最小化该目标；-1：最大化该目标）
        SFC=SFC
        Dim, lb, ub, lbin, ubin=self.get_SFC(SFC,cpu_num)
        varTypes = [1] * Dim  # 初始化varTypes（决策变量的类型，元素为0表示对应的变量是连续的；1表示是离散的）
        self.G=copy.deepcopy(G)
        self.event=event
        # 调用父类构造方法完成实例化
        ea.Problem.__init__(self, name, M, maxormins, Dim, varTypes, lb, ub, lbin, ubin)

    def evalVars(self, Vars):  # 目标函数
        f=[]
        for i in range(len(Vars)):
            link,link_num = self.compute_link(Vars[i])
            cpu_v=self.compute_cpu(Vars[i])#判断cpu
            bw_v=self.compute_bw(link,link_num)#判断bw
            lat_v=self.compute_lat(link,link_num)#判断latency
            f.append([cpu_v+bw_v+lat_v])
        f=np.mat(f)
        return f

    def compute_link(self,placement):
        link_temp = []
        for i in range(len(placement) - 1):
            sn_from = placement[i]
            sn_to = placement[i + 1]
            if nx.has_path(self.G, source=sn_from, target=sn_to):
                path = nx.shortest_path(self.G, sn_from, sn_to, weight='delay')
                link_temp.append(path)
        link_num = len(link_temp)
        # for i in range(len(link_temp)):
        #     if i == 0:
        #         for j in range(len(link_temp[i])):
        #             link.append(link_temp[i][j])
        #     else:
        #         j=1
        #         while j<len(link_temp[i]):
        #             link.append((link_temp[i][j]))
        #             j=j+1
        return link_temp, link_num

    def compute_cpu(self,placement):
        G1 = copy.deepcopy(self.G)
        cpu_v = 0

        for i in range(len(placement)):
            G1.nodes[placement[i]]['cpu_remain'] = G1.nodes[placement[i]]['cpu_remain'] - self.event.nodes[i]['r_cpu']
        for i in range(len(placement)):
            if G1.nodes[placement[i]]['cpu_remain']<0:
                cpu_v=cpu_v-G1.nodes[placement[i]]['cpu_remain']

        return cpu_v

    def compute_bw(self,link,link_num):
        bw_v=0
        G2=copy.deepcopy(self.G)
        for i in range(link_num):
            for j in range(len(link[i]) - 1):
                G2.edges[link[i][j], link[i][j + 1]]['bw_remain'] = G2.edges[link[i][j], link[i][j + 1]][
                                                                            'bw_remain'] - self.event.edges[i, i + 1]['r_bw']

        for i in range(link_num):
            for j in range(len(link[i]) - 1):
                if G2.edges[link[i][j], link[i][j + 1]]['bw_remain'] <0:
                    bw_v=bw_v-G2.edges[link[i][j], link[i][j + 1]]['bw_remain']
        return bw_v

    def compute_lat(self,link,link_num):
        G3 = copy.deepcopy(self.G)
        latency = 0
        for i in range(link_num - 1):
            for j in range(len(link[i]) - 1):
                latency = latency + G3.edges[link[i][j], link[i][j + 1]]['delay']
        if latency <= self.event.graph["max_latency"]:
            lat_v=0
        else:
            lat_v=latency-self.event.graph["max_latency"]
        return lat_v

    def calReferObjV(self):  # 设定目标数参考值（本问题目标函数参考值设定为理论最优值）
        referenceObjV = np.array([[0]])
        return referenceObjV

    def get_SFC(self,SFC,cpu_num):
        Dim=len(SFC)
        lb = []
        ub = []
        lbin = []
        ubin = []
        for i in range(len(SFC)):
            lb.append(0)  # 决策变量下界
            ub.append(cpu_num)  # 决策变量上界
            lbin.append(1)  # 决策变量下边界（0表示不包含该变量的下边界，1表示包含）
            ubin.append(0)  # 决策变量上边界（0表示不包含该变量的上边界，1表示包含）
        return Dim,lb,ub,lbin,ubin