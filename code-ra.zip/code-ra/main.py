import time

from DE.solver import DE
from DE.solver_ra import DE_r
from FF.solver import FF
from FF.solver_ra import FF_r
from model.solver import PgSeq2SeqSolver


def run(name):
    solver = PgSeq2SeqSolver()
    solver_ff=FF()
    solver_ff_r=FF_r()
    solver_de=DE()
    solver_de_r=DE_r()
    if name =="learn":
        solver.learn()
    elif name == "deplay":
        solver.deplay()
    elif name == "deplay_r":
        solver.deplay_ra()
    elif name == "deplay_ff":
        solver_ff.deplay()
    elif name == "deplay_ff_r":
        solver_ff_r.deplay()
    elif name =="deplay_de":
        solver_de.deplay()
    elif name =="deplay_de_r":
        solver_de_r.deplay()


# 按间距中的绿色按钮以运行脚本。
if __name__ == '__main__':
    time0=time.time()
    select="deplay_de"
    run(select)
    print(time.time()-time0)


